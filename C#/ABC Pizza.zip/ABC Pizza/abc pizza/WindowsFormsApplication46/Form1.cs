﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication46
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            adsoyad.Items.Add(textBox1.Text);
            telefon.Items.Add(textBox2.Text);
            adres.Items.Add(richTextBox1.Text);
            if(comboBox1.SelectedItem==0)

        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            richTextBox1.Clear();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            adsoyad.Items.Clear();
            telefon.Items.Clear();
            adres.Items.Clear();
            pizzaboyadet.Items.Clear();
        }
    }
}
